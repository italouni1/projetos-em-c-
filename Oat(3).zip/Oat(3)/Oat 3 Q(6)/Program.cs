﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_6_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira a temperatura em graus Celsius: ");
            double temperaturacelsius = double.Parse(Console.ReadLine());

            double temperaturafahrenheit = (9 * temperaturacelsius + 160) / 5;

            Console.WriteLine("A temperatura em graus Fahrenheit é: " + temperaturafahrenheit.ToString("") + "°F");
        }
    }

}

