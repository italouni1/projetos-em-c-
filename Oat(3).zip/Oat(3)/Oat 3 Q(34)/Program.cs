﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_34_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int menor = int.MaxValue;
            int maior = int.MinValue;

            Console.WriteLine("Insira um número positivo 'ou o número 10 para encerrar':");

            do
            {
                numero = int.Parse(Console.ReadLine());

                if (numero > 0)
                {
                    if (numero < menor)
                    {
                        menor = numero;
                    }

                    if (numero > maior)
                    {
                        maior = numero;
                    }
                }
            } while (numero >= 0);

            if (menor == int.MaxValue)
            {
                Console.WriteLine("Nenhum número foi inserido.");
            }
            else
            {
                Console.WriteLine("Menor número: {0}", menor);
                Console.WriteLine("Maior número: {0}", maior);
            }

            Console.ReadLine(); // Aguarda o pressionamento de uma tecla antes de fechar o programa.

            Console.WriteLine();
        }
    }


}
