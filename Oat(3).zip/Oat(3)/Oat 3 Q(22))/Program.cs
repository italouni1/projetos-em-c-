﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_22__
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int a = 0;
            int b = 0;

            Console.WriteLine("Insira um numero: ");
            string input = Console.ReadLine();

            if (int.TryParse(input, out numero))
            {
                if (numero > 0)
                {
                    a = numero;
                    Console.WriteLine("O numero e positivo e foi armazenado em A.");
                }
                else if (numero < 0)
                {
                    b = numero;
                    Console.WriteLine("O numero e negativo e foi armazenado em B.");
                }
                else
                {
                    Console.WriteLine("O numero digitado e zero.");
                }

                Console.WriteLine("Valor em A: " + a);
                Console.WriteLine("Valor em B: " + b);
            }
            else
            {
                Console.WriteLine("Numero invalido. Por favor, digite um numero valido.");
                Console.WriteLine();
            }
        }
    }

}
