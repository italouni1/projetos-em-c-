﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_21_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero;
            bool continuar = true;

            while (continuar)
            {
                Console.WriteLine("Insira um numero inteiro 'digite 2 para sair':");
                string input = Console.ReadLine();

                if (int.TryParse(input, out numero))
                {
                    if (numero > 0)
                    {
                        Console.WriteLine("O numero e positivo.");
                    }
                    else if (numero < 0)
                    {
                        Console.WriteLine("O numero e negativo.");
                    }
                    else
                    {
                        Console.WriteLine("O numero e zero. 'finalizando o programa'.");
                        continuar = false;
                    }
                }
                else
                {
                    Console.WriteLine("Numero invalido. Por favor, digite um numero inteiro valido.");
                }

                Console.WriteLine();
            }
        }
    }
    
}
