﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_33_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int matricula;
            double nota;
            int contadorAlunos = 0;
            double somaNotas = 0;

            Console.WriteLine("Insira o número de matrícula do aluno 'ou o numero 10 para encerrar':");

            do
            {
                Console.Write("Número de matrícula: ");
                matricula = int.Parse(Console.ReadLine());

                if (matricula >= 0)
                {
                    Console.Write("Nota na prova: ");
                    nota = double.Parse(Console.ReadLine());

                    contadorAlunos++;
                    somaNotas += nota;
                }
            } while (matricula >= 0);

            if (contadorAlunos > 0)
            {
                double media = somaNotas / contadorAlunos;
                Console.WriteLine("Média das notas: {0}", media);
            }
            else
            {
                Console.WriteLine("Nenhum aluno inserido.");
            }

            Console.ReadLine(); // Aguarda o apertando  uma tecla antes de fechar o programa .
            Console.WriteLine();

        }
    }
}
