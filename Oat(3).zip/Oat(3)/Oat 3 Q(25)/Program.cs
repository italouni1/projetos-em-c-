﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_25_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira a altura (em metros):");
            double altura = double.Parse(Console.ReadLine());

            Console.WriteLine("Insira o sexo (M para masculino ou F para feminino):");
            string sexo = Console.ReadLine();

            double pesoIdeal;

            if (sexo.ToUpper() == "M")
            {
                pesoIdeal = (72.7 * altura) - 58;
            }
            else if (sexo.ToUpper() == "F")
            {
                pesoIdeal = (62.1 * altura) - 44.7;
            }
            else
            {
                Console.WriteLine("Sexo inválido. Por favor, digite M ou F.");
                return;
            }

            Console.WriteLine("O peso ideal para uma pessoa com altura " + altura + " metros e sexo " + sexo.ToUpper() + " é: " + pesoIdeal + " kg.");
            Console.WriteLine();

        }
    }
}
