﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_Q_49_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Tamanho dos vetores
            int n = 0;
            do
            {
                Console.Write("Insira o tamanho dos vetores (entre 1 e 50): ");
                n = int.Parse(Console.ReadLine());
            } while (n < 1 || n > 50);

            // Vetores V1 e V2
            int[] v1 = new int[n];
            int[] v2 = new int[n];

            // Ler os elementos dos vetores V1 e V2
            Console.WriteLine("Insira os elementos do vetor V1:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("Elemento {0}: ", i + 1);
                v1[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Insira os elementos do vetor V2:");
            for (int i = 0; i < n; i++)
            {
                Console.Write("Elemento {0}: ", i + 1);
                v2[i] = int.Parse(Console.ReadLine());
            }

            // Contador de valores idênticos nas mesmas posições
            int contador = 0;

            // Verificar os valores idênticos nas mesmas posições
            for (int i = 0; i < n; i++)
            {
                if (v1[i] == v2[i])
                {
                    contador++;
                }
            }

            // Exibir o resultado
            Console.WriteLine("Quantidade de valores idênticos nas mesmas posições: " + contador);
        }
    }

}
