﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_2_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Informe a cotação do dólar: ");
            double cotacaoDolar = double.Parse(Console.ReadLine());

            Console.WriteLine("Informe o valor em dólares: ");
            double valorDolar = double.Parse(Console.ReadLine());

            double valorReal = valorDolar * cotacaoDolar;

            Console.WriteLine("O valor em reais é: R$" + valorReal.ToString("F4"));

        }
    }
}
