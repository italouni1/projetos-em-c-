﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_1_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira a quantidade mínima de peças: ");
            int quantidadeMinima = int.Parse(Console.ReadLine());

            Console.WriteLine("Insira a quantidade máxima de peças: ");
            int quantidadeMaxima = int.Parse(Console.ReadLine());

            double estoqueMedio = (quantidadeMinima + quantidadeMaxima) / 2.0;

            Console.WriteLine("O estoque médio é: " + estoqueMedio);
            
        }
    }
}
