﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_31_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int somaPares = 0;
            int somaImpares = 0;

            Console.WriteLine("insira um número positivo 'ou um número negativo para encerrar':");

            do
            {
                numero = int.Parse(Console.ReadLine());

                if (numero > 0)
                {
                    if (numero % 2 == 0)
                    {
                        Console.WriteLine("{0} é par", numero);
                        somaPares += numero;
                    }
                    else
                    {
                        Console.WriteLine("{0} é ímpar", numero);
                        somaImpares += numero;
                    }
                }
            } while (numero >= 0);

            Console.WriteLine("Soma dos números pares: {0}", somaPares);
            Console.WriteLine("Soma dos números ímpares: {0}", somaImpares);

            Console.ReadLine(); // Aguarda apertando uma tecla antes de fechar o programa .

        }
    }
}
