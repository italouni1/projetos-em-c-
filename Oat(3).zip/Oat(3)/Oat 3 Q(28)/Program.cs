﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_28_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Números ímpares entre 100 e 200:");

            for (int i = 101; i <= 199; i += 2)
            {
                Console.WriteLine(i);
            }
        }
    }


}
