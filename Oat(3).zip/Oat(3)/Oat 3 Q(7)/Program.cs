﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_7_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira a temperatura em graus Fahrenheit: ");
            double temperaturafahrenheit = double.Parse(Console.ReadLine());

            double temperaturacelsius = (temperaturafahrenheit - 32) * 5 / 9;

            Console.WriteLine("A temperatura em graus Celsius é: " + temperaturacelsius.ToString("") + "°C");

        }
    }
}
