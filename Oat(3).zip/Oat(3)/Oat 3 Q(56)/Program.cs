﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_56_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] vetor = new int[50];

            // Lê os valores do vetor
            for (int i = 0; i < vetor.Length; i++)
            {
                Console.Write("Insira o valor para a posição {0}: ", i);
                vetor[i] = int.Parse(Console.ReadLine());
            }

            int quantidadePares = 0;
            int quantidadeMultiplosDe5 = 0;

            // Verifica a quantidade de números pares e múltiplos de 5
            foreach (int numero in vetor)
            {
                if (numero % 2 == 0)
                    quantidadePares++;

                if (numero % 5 == 0)
                    quantidadeMultiplosDe5++;
            }

            Console.WriteLine("Quantidade de números pares: {0}", quantidadePares);
            Console.WriteLine("Quantidade de múltiplos de 5: {0}", quantidadeMultiplosDe5);

            Console.ReadLine();
        }
    }

}