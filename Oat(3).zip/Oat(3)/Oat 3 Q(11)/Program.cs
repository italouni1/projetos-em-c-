﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_11_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira o valor de A: ");
            int a = int.Parse(Console.ReadLine());

            Console.WriteLine("Insira o valor de B: ");
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine("Valores originais:");
            Console.WriteLine("A: " + a);
            Console.WriteLine("B: " + b);

            // Troca dos valores
            int temp = a;
            a = b;
            b = temp;

            Console.WriteLine("Valores trocados:");
            Console.WriteLine("A: " + a);
            Console.WriteLine("B: " + b);

        }
    }
}
