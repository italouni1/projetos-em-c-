﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_47_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Tamanho do vetor
            int tamanhoVetor = 10;

            // Criar vetor
            int[] vetor = new int[tamanhoVetor];

            // Ler os elementos do vetor
            Console.WriteLine("Insira os elementos do vetor:");
            for (int i = 0; i < tamanhoVetor; i++)
            {
                Console.Write("Elemento {0}: ", i + 1);
                vetor[i] = int.Parse(Console.ReadLine());
            }

            // Ler o número X
            Console.Write("Insira o número X: ");
            int numeroX = int.Parse(Console.ReadLine());

            // Contadores
            int maioresQueX = 0;
            int menoresQueX = 0;
            int iguaisAX = 0;

            // Verificar os números no vetor
            for (int i = 0; i < tamanhoVetor; i++)
            {
                if (vetor[i] > numeroX)
                {
                    maioresQueX++;
                }
                else if (vetor[i] < numeroX)
                {
                    menoresQueX++;
                }
                else
                {
                    iguaisAX++;
                }
            }

            // Exibir os resultados
            Console.WriteLine("Quantidade de números maiores que X: " + maioresQueX);
            Console.WriteLine("Quantidade de números menores que X: " + menoresQueX);
            Console.WriteLine("Quantidade de números iguais a X: " + iguaisAX);
        }

    }
}
