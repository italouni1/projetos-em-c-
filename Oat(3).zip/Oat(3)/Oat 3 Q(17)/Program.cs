﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_17_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Insira um número inteiro: ");
            int numero = Convert.ToInt32(Console.ReadLine());

            if (numero >= 0 && numero <= 9)
            {
                Console.WriteLine("Valor valido");
            }
            else
            {
                Console.WriteLine("Valor invalido");
            }
        }
    }

}