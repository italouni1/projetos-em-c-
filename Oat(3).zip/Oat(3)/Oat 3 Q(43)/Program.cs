﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_43_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ulong totalGrains = 0; // Usamos ulong para acomodar números grandes

            for (int i = 0; i < 64; i++)
            {
                ulong grainsOnSquare = (ulong)Math.Pow(2, i);
                totalGrains += grainsOnSquare;
            }

            Console.WriteLine("O número total de grãos esperado pelo monge é: " + totalGrains);
        }
    }

}
