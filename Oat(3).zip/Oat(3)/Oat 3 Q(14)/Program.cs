﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_14_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira dois números:");

            Console.Write("Número 1: ");
            double numero1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Número 2: ");
            double numero2 = Convert.ToDouble(Console.ReadLine());

            double diferenca;

            if (numero1 > numero2)
            {
                diferenca = numero1 - numero2;
                Console.WriteLine("A diferença entre o maior e o menor número é: " + diferenca);
            }
            else if (numero2 > numero1)
            {
                diferenca = numero2 - numero1;
                Console.WriteLine("A diferença entre o maior e o menor número é: " + diferenca);
            }
            else
            {
                Console.WriteLine("Os números são iguais. A diferença entre eles é zero.");
            }
        }
    }

}
