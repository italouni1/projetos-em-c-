﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_18_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Insira um número inteiro: ");
            int codigo = Convert.ToInt32(Console.ReadLine());

            string valorPorExtenso;

            switch (codigo)
            {
                case 1:
                    valorPorExtenso = "um";
                    break;
                case 2:
                    valorPorExtenso = "dois";
                    break;
                case 3:
                    valorPorExtenso = "tres";
                    break;
                default:
                    Console.WriteLine("Codigo invalido");
                    return;
            }

            Console.WriteLine("O valor por extenso do codigo e: " + valorPorExtenso);

        }
    }
}
