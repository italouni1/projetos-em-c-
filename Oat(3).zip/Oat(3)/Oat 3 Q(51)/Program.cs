﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_51_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Insira a quantidade de alunos: ");
            int quantidadeAlunos = int.Parse(Console.ReadLine());

            double[] notas = new double[quantidadeAlunos];
            double somaNotas = 0;
            int alunosAcimaDeSete = 0;

            for (int i = 0; i < quantidadeAlunos; i++)
            {
                Console.Write("Insira a nota do aluno " + (i + 1) + ": ");
                notas[i] = double.Parse(Console.ReadLine());
                somaNotas += notas[i];

                if (notas[i] > 7.0)
                {
                    alunosAcimaDeSete++;
                }
            }

            if (quantidadeAlunos > 0)
            {
                double media = somaNotas / quantidadeAlunos;
                Console.WriteLine("A média aritmética das notas é: " + media.ToString("F2"));

                if (alunosAcimaDeSete > 0)
                {
                    Console.WriteLine("Quantidade de alunos com nota acima de 7.0: " + alunosAcimaDeSete);
                }
                else
                {
                    Console.WriteLine("Não há nenhum aluno com nota acima de 7.0.");
                }
            }
            else
            {
                Console.WriteLine("Nenhum aluno foi inserido.");
            }

            Console.ReadLine();
        }
    }

}
