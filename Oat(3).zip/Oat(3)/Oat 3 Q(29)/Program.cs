﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_29_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 2000; i++)
            {
                Console.WriteLine(i);
            }

            Console.ReadLine(); // Aguarda o pressionamento de uma tecla antes de fechar o programa .

        }
    }
}
