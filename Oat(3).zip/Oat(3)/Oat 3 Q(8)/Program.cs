﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_8_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira o raio da lata de óleo: ");
            double raio = double.Parse(Console.ReadLine());

            Console.WriteLine("Insira a altura da lata de óleo: ");
            double altura = double.Parse(Console.ReadLine());

            double volume = Math.PI * Math.Pow(raio, 2) * altura;

            Console.WriteLine("O volume da lata de óleo é: " + volume.ToString(""));

        }
    }
}
