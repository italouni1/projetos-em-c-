﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_36_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int quantidadeValores = 10;
            int maior = int.MinValue;
            int menor = int.MaxValue;
            int soma = 0;

            Console.WriteLine("Insira {0} valores inteiros e positivos:", quantidadeValores);

            for (int i = 0; i < quantidadeValores; i++)
            {
                int valor = LerValorInteiroPositivo();

                if (valor > maior)
                {
                    maior = valor;
                }

                if (valor < menor)
                {
                    menor = valor;
                }

                soma += valor;
            }

            double media = (double)soma / quantidadeValores;

            Console.WriteLine("Maior valor: {0}", maior);
            Console.WriteLine("Menor valor: {0}", menor);
            Console.WriteLine("Média dos valores: {0}", media);

            Console.ReadLine(); // Aguarda o pressionamento de uma tecla antes de fechar o programa
        }

        static int LerValorInteiroPositivo()
        {
            int valor;
            bool valorValido;

            do
            {
                Console.Write("Digite um valor inteiro positivo: ");
                string input = Console.ReadLine();

                valorValido = int.TryParse(input, out valor);

                if (!valorValido || valor <= 0)
                {
                    Console.WriteLine("Valor inválido. Digite um valor inteiro positivo.");
                }

            } while (!valorValido || valor <= 0);

            return valor;
        }
    }

}
