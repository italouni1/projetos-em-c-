﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_9_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira a idade em anos: ");
            int anos = int.Parse(Console.ReadLine());

            Console.WriteLine("Insira a idade em meses: ");
            int meses = int.Parse(Console.ReadLine());

            Console.WriteLine("Insira a idade em dias: ");
            int dias = int.Parse(Console.ReadLine());

            int idadeemdias = anos * 365 + meses * 30 + dias;

            Console.WriteLine("A sua idade em dias é: " + idadeemdias + " dias");

        }
    }
}
