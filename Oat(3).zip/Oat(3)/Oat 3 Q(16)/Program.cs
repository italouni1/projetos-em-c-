﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_16_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira dois números:");

            Console.Write("Número 1: ");
            double numero01 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Número 2: ");
            double numero02 = Convert.ToDouble(Console.ReadLine());

            if (numero01 > numero02)
            {
                Console.WriteLine("O maior número é: " + numero01);
                Console.WriteLine("O menor número é: " + numero02);
            }
            else if (numero02 > numero01)
            {
                Console.WriteLine("O maior número é: " + numero02);
                Console.WriteLine("O menor número é: " + numero01);
            }
            else
            {
                Console.WriteLine("Os dois números são iguais: " + numero01);
                Console.WriteLine("++");
            }
        }
    }

}
