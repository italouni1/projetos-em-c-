﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_10_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira o primeiro número: ");
            int numero1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Insira o segundo número: ");
            int numero2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Relacionamentos de ordem:");

            if (numero1 == numero2)
            {
                Console.WriteLine("Igual");
            }
            else
            {
                Console.WriteLine("Não igual");

                if (numero1 > numero2)
                {
                    Console.WriteLine("Maior");
                    Console.WriteLine("Maior ou igual");
                }
                else
                {
                    Console.WriteLine("Menor");
                    Console.WriteLine("Menor ou igual");
                }
            }
        }
    }

}
