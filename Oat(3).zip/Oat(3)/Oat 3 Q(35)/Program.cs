﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_35_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 100; i++)
            {
                Console.WriteLine(i);

                if (i % 10 == 0)
                {
                    Console.WriteLine("Múltiplo de 10");
                }
            }

            Console.ReadLine(); // Aguarda o pressionamento de uma tecla antes de fechar o programa
        }
    }

}
