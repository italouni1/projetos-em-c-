﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_12_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Insira um número inteiro: ");
            int numero = Convert.ToInt32(Console.ReadLine());

            int modulo = Math.Abs(numero);

            Console.WriteLine("O módulo do número é: " + modulo);

        }
    }
}
