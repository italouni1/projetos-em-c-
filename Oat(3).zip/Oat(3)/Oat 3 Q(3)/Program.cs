﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_3_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira a identificação do vendedor: ");
            int identificacaoVendedor = int.Parse(Console.ReadLine());

            Console.WriteLine("Insira o código da peça: ");
            int codigoPeca = int.Parse(Console.ReadLine());

            Console.WriteLine("Insira o preço unitário da peça: ");
            double precoUnitario = double.Parse(Console.ReadLine());

            Console.WriteLine("Insira a quantidade vendida: ");
            int quantidadeVendida = int.Parse(Console.ReadLine());

            double totalVenda = precoUnitario * quantidadeVendida;
            double comissao = totalVenda * 0.05;

            Console.WriteLine("Identificação do vendedor: " + identificacaoVendedor);
            Console.WriteLine("Código da peça: " + codigoPeca);
            Console.WriteLine("Total da venda: R$" + totalVenda.ToString(""));
            Console.WriteLine("Comissão do vendedor: R$" + comissao.ToString(""));
        }
        
    }
}

