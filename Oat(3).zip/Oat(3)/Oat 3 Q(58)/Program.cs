﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_58_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Insira a quantidade de números a serem lidos: ");
            int quantidadeNumeros = int.Parse(Console.ReadLine());

            int[] numeros = new int[quantidadeNumeros];

            // Lê os números e armazena no vetor
            for (int i = 0; i < quantidadeNumeros; i++)
            {
                Console.Write("Insira o número {0}: ", i + 1);
                numeros[i] = int.Parse(Console.ReadLine());
            }

            // Calcula a média
            double soma = 0;
            foreach (int numero in numeros)
            {
                soma += numero;
            }
            double media = soma / quantidadeNumeros;

            // Encontra o maior valor
            int maior = int.MinValue;
            foreach (int numero in numeros)
            {
                if (numero > maior)
                    maior = numero;
            }

            Console.WriteLine("Média: {0}", media);
            Console.WriteLine("Maior valor: {0}", maior);

            Console.ReadLine();
        }
    }

}
