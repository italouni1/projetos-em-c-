﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_Q_42_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int maior = int.MinValue; // Inicializa o maior com o menor valor possível
            int menor = int.MaxValue; // Inicializa o menor com o maior valor possível

            do
            {
                Console.WriteLine("Insira um número (ou 0 para sair):");
                numero = int.Parse(Console.ReadLine());

                if (numero != 0)
                {
                    if (numero > maior)
                    {
                        maior = numero;
                    }

                    if (numero < menor)
                    {
                        menor = numero;
                    }
                }
            } while (numero != 0);

            Console.WriteLine("O maior número é: " + maior);
            Console.WriteLine("O menor número é: " + menor);
        }
    }

}
