﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_62_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Console.Write(\"Digite o valor da base do triângulo: \");\r\n        double baseTriangulo = double.Parse(Console.ReadLine());\r\n\r\n        Console.Write(\"Digite o valor da altura do triângulo: \");\r\n        double alturaTriangulo = double.Parse(Console.ReadLine());\r\n\r\n        double hipotenusa = Hipotenusa(baseTriangulo, alturaTriangulo);\r\n        double area = (baseTriangulo * alturaTriangulo) / 2;\r\n\r\n        Console.WriteLine(\"Hipotenusa do triângulo: {0}\", hipotenusa);\r\n        Console.WriteLine(\"Área do triângulo: {0}\", area);\r\n\r\n        Console.ReadLine();\r\n    }\r\n\r\n    static double Hipotenusa(double baseTriangulo, double alturaTriangulo)\r\n    {\r\n        double hipotenusaQuadrado = Math.Pow(baseTriangulo, 2) + Math.Pow(alturaTriangulo, 2);\r\n        double hipotenusa = Math.Sqrt(hipotenusaQuadrado);\r\n        return hipotenusa;\r\n    }\r\n}\r\n o valor da base do triângulo: ");
            double baseTriangulo = double.Parse(Console.ReadLine());

            Console.Write("Insira o valor da altura do triângulo: ");
            double alturaTriangulo = double.Parse(Console.ReadLine());

            double hipotenusa = Hipotenusa(baseTriangulo, alturaTriangulo);
            double area = (baseTriangulo * alturaTriangulo) / 2;

            Console.WriteLine("Hipotenusa do triângulo: {0}", hipotenusa);
            Console.WriteLine("Área do triângulo: {0}", area);

            Console.ReadLine();
        }

        static double Hipotenusa(double baseTriangulo, double alturaTriangulo)
        {
            double hipotenusaQuadrado = Math.Pow(baseTriangulo, 2) + Math.Pow(alturaTriangulo, 2);
            double hipotenusa = Math.Sqrt(hipotenusaQuadrado);
            return hipotenusa;
        }
    }

}
