﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_19_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira os tres valores dos lados do triangulo:");

            Console.Write("Lado A: ");
            double ladoa = Convert.ToDouble(Console.ReadLine());

            Console.Write("Lado B: ");
            double ladob = Convert.ToDouble(Console.ReadLine());

            Console.Write("Lado C: ");
            double ladoc = Convert.ToDouble(Console.ReadLine());

            if (VerificarTriangulo(ladoa, ladob, ladoc))
            {
                if (ladoa == ladob && ladob == ladoc)
                {
                    Console.WriteLine("O triangulo é equilatero");
                }
                else if (ladoa == ladob || ladoa == ladoc || ladob == ladoc)
                {
                    Console.WriteLine("O triangulo e isosceles");
                }
                else
                {
                    Console.WriteLine("O triangulo e escaleno");
                }
            }
            else
            {
                Console.WriteLine("Os valores fornecidos nao formam um triangulo");
            }
        }

        static bool VerificarTriangulo(double ladoa, double ladob, double ladoc)
        {
            return ladoa < ladob + ladoc && ladob < ladoa + ladoc && ladoc < ladoa + ladob;
        }
    }

}