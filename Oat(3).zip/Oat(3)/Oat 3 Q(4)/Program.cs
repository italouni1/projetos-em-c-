﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_4_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira o valor de a: ");
                int a = int.Parse(Console.ReadLine());

            Console.WriteLine("Insira o valor de b: ");
                int b = int.Parse(Console.ReadLine());

            Console.WriteLine("Insira o valor de c: ");
                int c = int.Parse(Console.ReadLine());

            Console.WriteLine("Insira o valor de d: ");
                int d = int.Parse(Console.ReadLine());

                int resultado;

            resultado = a * b;
            Console.WriteLine($"a * b = {resultado}");

            resultado = a * c;
            Console.WriteLine($"a * c = {resultado}");

            resultado = a * d;
            Console.WriteLine($"a * d = {resultado}");

            resultado = b * c;
            Console.WriteLine($"b * c = {resultado}");

            resultado = b * d;
            Console.WriteLine($"b * d = {resultado}");

            resultado = c * d;
            Console.WriteLine($"C * D = {resultado}");

            resultado = a + b;
            Console.WriteLine($"a + b = {resultado}");

            resultado = a + c;
            Console.WriteLine($"a + c = {resultado}");

            resultado = a + d;
            Console.WriteLine($"a + d = {resultado}");

            resultado = b + c;
            Console.WriteLine($"b + c = {resultado}");

            resultado = b + d;
            Console.WriteLine($"b + d = {resultado}");

            resultado = c + d;
            Console.WriteLine($"c + d = {resultado}");
        }
    }

}
    
