﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_3_Q_5_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Insira o tempo gasto na viagem [em horas]: ");
            double tempogasto = double.Parse(Console.ReadLine());

            Console.WriteLine("Insira a velocidade media [em Km/h]: ");
            double velocidademedia = double.Parse(Console.ReadLine());

            double distancia = tempogasto * velocidademedia;
            double litrosusados = distancia / 12;

            Console.WriteLine("Velocidade media: " + velocidademedia + " Km/h");
            Console.WriteLine("Tempo gasto: " + tempogasto + " horas");
            Console.WriteLine("Distância percorrida: " + distancia + " Km");
            Console.WriteLine("Quantidade de litros utilizada na viagem: " + litrosusados.ToString("") + " litros");
        }
    }

}
   